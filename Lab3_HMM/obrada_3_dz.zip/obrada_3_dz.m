addpath(genpath('D:\Fran\Documents\FER\5. semestar\Obrada informacija\Lab3\HMM\HMMall'))
testHMM
%% 

% ===============================================================
% Oznacavanje stanja HMM modela
% Imamo tri pristrane kocke od kojih uvijek bacamo jednu odabranu
% Stanja modela su indeksi koristene pristrane kocke
% Vektor inicijalne vjerojatnosti stanja (za t=1)
% odredjen bacanjem nepristrane kocke:
prior0=[
1 % Prva kocka (ako je palo '1')
2 % Druga kocka (ako je palo '2' ili '3')
3 % Treca kocka (ako je palo '4', '5' ili '6')
]/6;
% Broj stanja HMM modela
Q=size(prior0,1);

% ---------------------------------------------------------------
% Matrica vjerojatnosti promjena stanja
%
% a11 a12 a13
% a21 a22 a23
% a31 a32 a33
% Za eksperiment sa stohastickom izmjenom stanja, parametar
% M se koristi za definiranje vjerojatnosi prijelaza u
% novo stanje u matrici prijelaza A, pri cemu se stanja nuzno
% mijenjaju ciklicki radi forsirane strukture tranzicijske matrice.
M= 7; % Ovdje definirate M iz vaseg personaliziranog zadatka.
% Formiraj matricu vjerojatnosti prijelaza stanja
% (uz ciklicku strukturu izmjene stanja, jer su
% prijelazi 1->3, 2->1 i 3->2 zabranjeni)
transmat0=[
M-1 1 0 % P(1|1) P(2|1) P(3|1)
0 M-1 1 % P(1|2) P(2|2) P(3|2)
1 0 M-1 % P(1|3) P(2|3) P(3|3)
]/M;

% Matrica emisijskih vjerojatnosti
% svaki redak odgovara jednom stanju, a
% svaki stupac jednoj mogucoj opservaciji
% Matrica učestalosti osmatranja (prema slici)
B_count = [
    20,  5,  5,  6,  2,  2;  % Kocka 1
     5, 5,  20,  5,  3,  2;  % Kocka 2
     6,  7,  3,  1, 20,  3   % Kocka 3
];

% Ukupan broj bacanja po kocki
num_rolls = 40;

% Izračun matrice emisijskih vjerojatnosti
obsmat0 = B_count / num_rolls;
O=size(obsmat0,2);

%% 
data1=[ 3 3 1 4 5 2 1 1 2 3 5 1 1 1 1 6 1 5 5 5 5 5 5 5 5 6 5 6 5 5 4 1 4 5 5 5 5 5 5 1 1];
data2=[ 6 5 2 2 4 2 6 2 4 6 5 2 2 2 6 6 6 3 6 6 6 6 4 5 3 6 6 6 6 6 3 6 6 3 6 4 5 2 4 1 2];

if ~iscell(data1)
data1 = num2cell(data1, 2);
end
ncases1 = length(data1);

if ~iscell(data2)
data2 = num2cell(data2, 2);
end
ncases2 = length(data2);

loglik1 = 0;
errors1 = [];
for m=1:ncases1
obslik01 = multinomial_prob(data1{m}, obsmat0);
[alpha1, beta1, gamma1, ll1] = ...
fwdback(prior0, transmat0, obslik01, 'scaled', 0);
if ll1==-inf
errors1 = [errors1 m];
end
loglik1 = loglik1 + ll1;
end

loglik2 = 0;
errors2 = [];
for m=1:ncases2
obslik02 = multinomial_prob(data2{m}, obsmat0);
[alpha2, beta2, gamma2, ll2] = ...
fwdback(prior0, transmat0, obslik02, 'scaled', 0);
if ll2==-inf
errors2 = [errors2 m];
end
loglik2 = loglik2 + ll2;
end

ll1

ll2

%% 

alpha1(3, 25)
beta1(3, 12)

%% 

% Najizvjesniji put
vpath1 = viterbi_path(prior0, transmat0, obslik01)

% Najizvjesniji put
vpath2 = viterbi_path(prior0, transmat0, obslik02)

[ll11, p11] = dhmm_logprob_path(prior0, transmat0, obslik01, vpath1)
[ll22, p22] = dhmm_logprob_path(prior0, transmat0, obslik02, vpath2)

ll11
ll22

ll1 - ll11
ll2 - ll22

%%
alpha1(1,4) + alpha1(2,4) + alpha1(3,4)

data3=[3 3 1 4];

if ~iscell(data3)
data3 = num2cell(data3, 2);
end
ncases3 = length(data3);

loglik3 = 0;
errors3 = [];
for m=1:ncases3
obslik03 = multinomial_prob(data3{m}, obsmat0);
[alpha3, beta3, gamma3, ll3] = ...
fwdback(prior0, transmat0, obslik03, 'scaled', 0);
if ll3==-inf
errors3 = [errors3 m];
end
loglik3 = loglik3 + ll3;
end

vpath3 = viterbi_path(prior0, transmat0, obslik03)
[ll33, p33] = dhmm_logprob_path(prior0, transmat0, obslik03, vpath3)

vpath3

%%
% Generiranje svih mogućih puteva za 4 stupca (vrijednosti od 1 do 3)
[grid1, grid2, grid3, grid4] = ndgrid(1:3, 1:3, 1:3, 1:3);

% Kombinacija svih vrijednosti u matricu
mpath = [grid1(:), grid2(:), grid3(:), grid4(:)];

% Prikaz rezultata
mpath

llm=zeros(81,1); % Stupac za log-izvjesnosti
for i=1:81,
[llm(i), p] = dhmm_logprob_path(prior0, transmat0, obslik03, mpath(i,:));
end;

count_inf = sum(isinf(llm) & llm < 0);
count_inf

%%

% Sortiraj puteve prema izvjesnosti osmatranja od najizvjesnijeg do
% najmanje izvjesnog
[sllm,illm]=sort(-llm);
% Kumulativno zbrojih izvjesnosti od samo jednog najizvjesnijeg
% puta, pa prva dva puta stanja po izvjesnosti, pa prva tri, ... i
% tako sve do sume izvjesnosti po svim mogucim putevima stanja
cumsum(exp(-sllm))

%%

rng('default')

T = 188; % duljina svakog niza
nex = 19; % broj opservacijskih nizova
dataRG = dhmm_sample(prior0, transmat0, obsmat0, nex, T);

%%

hm=hist(dataRG',[1 2 3 4 5 6])

a0=transmat0; for i=1:188, a0=a0*transmat0; end;
a0

teorijska_vjerovatnost = a0(1,:)*obsmat0

empiriskeVjerovatnosti = hm /188

row_means = mean(empiriskeVjerovatnosti, 2);
row_means

row_means - teorijska_vjerovatnost'
%% 

% Izracunaj u petlji log-izvjesnosti svakog niza
nex2=size(dataRG,1); % Broj eksperimenata
llm2=zeros(nex2,1); % Stupac log-izvjesnosti
for i=1:nex2,
llm2(i)=dhmm_logprob(dataRG(i,:), prior0, transmat0, obsmat0);
end;

llm2

max_value = max(llm2);      % Najveća vrijednost
min_value = min(llm2);      % Najmanja vrijednost
mean_value = mean(llm2);    % Srednja vrijednost

max_value
min_value
mean_value

%%

rng('default')
prior1 = normalise(rand(Q,1));
transmat1 = mk_stochastic(rand(Q,Q));
obsmat1 = mk_stochastic(rand(Q,O))

[LL222, prior222, transmat222, obsmat222] = dhmm_em(dataRG, prior1, transmat1, obsmat1, 'max_iter', 200, 'thresh', 1e-6);
%%
[LL333, prior333, transmat333, obsmat333] = dhmm_em(dataRG, prior0, transmat0, obsmat0, 'max_iter', 200, 'thresh', 1e-6);

%%
ll00=dhmm_logprob(dataRG, prior0, transmat0, obsmat0)

ll11=dhmm_logprob(dataRG, prior1, transmat1, obsmat1)

ll22=dhmm_logprob(dataRG, prior222, transmat222, obsmat222)

ll33=dhmm_logprob(dataRG, prior333, transmat333, obsmat333)

